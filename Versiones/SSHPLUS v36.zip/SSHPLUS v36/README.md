﻿# SSHPLUS MANAGER
```
* UPDATE 20/04/2021 - PROYECTO FINALIZADO
```
![logo](https://github.com/requmen/SSHPLUS-MANAGER-FREE/blob/master/Imagenes/SSHPLUS_MANAGER.jpg)

```
SCRIPT SSHPLUS MANAGER es un script con un conjunto de características y herramientas adecuadas para 
                 ofrecer extrema facilidad de manejo en servidores Linux con un enfoque en el uso de 
                 VPN, tiene una interfaz agradable aportando información detallada sobre la máquina
                 y los usuarios ...
```

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian)
* Ubuntu 14.04 Server x86_64 / Ubuntu 16.04 Server x86_64  / Ubuntu 18.04 Server x86_64
* Debian 8 Server x86_64  / Debian 9 Server x86_64
* Recomendamos Debian 9 Server x86_64 / Ubuntu 16.04 Server x86_64
* Se recomienda usar una distro nueva o formatiada
* Para instalar el segundo menu adaptado ejecute el comando ( menuV2 )
* Para instalar el tercer menu adaptado formato ADM ejecute el comando ( menuV3 
* Para instalar el cuarto menu adaptado formato ADM con utilitarios ejecute el comando ( menuV4 )
* Para restablecer el menu original ejecute el comando ( menuV1 )

## :book: Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/requmen/SSHPLUS-MANAGER-FREE/master/Plus; chmod 777 Plus; ./Plus

```
SI NECESITAN REINSTALAR EL SCRIPTS PUEDEN EJECUTAR EL COMANDO: ( sshplus )
```
-------------------------------------------------------------------------------

## :book: Installation Utilitarios

1. [SCRIPT OFICIAL PAINEL SSHPLUS WEB VERSAO: 20 (Installation Directa)](https://github.com/requmen/SSHPLUS-MANAGER-FREE/tree/master/Install/Panel_Web)
2. [PAINEL SSHPLUS WEB (VERSIONES)](https://github.com/requmen/SSHPLUS-MANAGER-FREE/tree/master/Install/Panel_Web)
3. [GENERADOR DE KEY SSHPLUS MANAGER](https://github.com/requmen/SSHPLUS-MANAGER-FREE/tree/master/Install/Generador)
4. [MULTI-INTALADOR SSHPLUS](https://github.com/requmen/SSHPLUS-MANAGER-FREE/tree/master/Install/Multi-Instalador)
5. [TCP-Tweaker-1.0 (TCP-SPEED)](https://github.com/requmen/SSHPLUS-MANAGER-FREE/tree/master/Install/TCP-Speed)
6. [INSTALL ARQUIVOS ORIGINALES ENCRIPTADOS POR @crazy_vpn](https://github.com/requmen/SSHPLUS-MANAGER-FREE/tree/master/Install/Sistema)

-------------------------------------------------------------------------------

## :scroll: Registro de cambios

**VERSION: 36**

https://raw.githubusercontent.com/requmen/SSHPLUS-MANAGER-FREE/master/versao

## :octocat: Contribute

1. @crazy_vpn - Developer of SSHPlus Manager
2. Team Illuminati - Contributor 

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆
```

**By: [  ⃘⃤꙰✰ ]**